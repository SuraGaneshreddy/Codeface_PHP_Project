# 🚀 Deploying Codeface

Codeface is plain **PHP 8 + PDO + a MySQL-or-SQLite database** — no Composer, no Node
server, no build step. That means it runs almost anywhere that offers PHP:

| Option | Cost | Best for | Effort |
|---|---|---|---|
| **A. XAMPP + Cloudflare / ngrok tunnel** | ₹0 | viva & demo day — laptop stays the server | 5 min |
| **B. InfinityFree (shared PHP+MySQL)** | ₹0 | always-on public link for your resume | 20 min |
| **C. Cloud VPS (GitHub Student Pack)** | ₹0 with student credits | best experience — SSE live rooms at full fidelity | 45 min |
| **D. Docker (Render / Railway / any box)** | free tier | reproducible container deploys | 15 min |

Requirements (all options): **PHP 8.0+** with `pdo_mysql` **or** `pdo_sqlite`,
Apache-compatible URL handling. The schema + demo data are created automatically on
first request — there is no import step.

---

## A. Viva / demo day — laptop + public tunnel (recommended for presentations)

No internet dependency for the app itself, instant public HTTPS link to share.

```bash
# 1. start the app (Windows: use XAMPP's php.exe)
cd codeface
PHP_CLI_SERVER_WORKERS=10 php -S 127.0.0.1:8000

# 2. share it publicly — pick one:
cloudflared tunnel --url http://localhost:8000   # Cloudflare quick tunnel (no account needed)
ngrok http 8000                                  # ngrok (free account)
```

You get `https://<random>.trycloudflare.com` (or `.ngrok-free.app`) — the root URL
redirects to `frontend/` automatically. Opening it on a **second device** (phone on
mobile data) is a killer rooms demo. JSON APIs work through tunnels because real
browsers execute the JS challenge/cookies themselves.

> Demo tip: JS problems run 100% in the browser (Web Workers) so the judge works even
> fully offline. Python needs the Pyodide CDN once per page load — if the venue has no
> internet, demo JavaScript problems.

---

## B. Free shared hosting — InfinityFree (always-on link)

InfinityFree gives free PHP 8 + MySQL + a free subdomain (e.g. `codeface.free.nf`)
with phpMyAdmin and FTP. Alternatives: AwardSpace, GoogieHost, HelioHost.

1. **Sign up** at infinityfree.com → create hosting account → note your subdomain.
2. **Create the MySQL database** in the panel (Databases → MySQL). Note the 4 values:
   - host like `sql123.infinityfree.com` (⚠️ **not** `localhost`)
   - database name like `if0_12345678_codeface`, username, password.
3. **Upload** `codeface/` contents into `htdocs/` (File Manager or FileZilla).
   Upload the provided `codeface-deploy.zip` and *Extract* it there.
   ⚠️ FTP clients sometimes skip hidden files — after upload, **verify** these exist:
   `/.htaccess`, `backend/lib/.htaccess`, `backend/config/.htaccess`,
   `database/.htaccess`, `database/data/.htaccess`. They block downloading your code
   and database; without them anyone can fetch `database/data/codeface.sqlite`.
4. **Point the app at MySQL** — edit `backend/config/config.php`:
   ```php
   'driver' => 'mysql',
   'mysql'  => [
       'host' => 'sql123.infinityfree.com',   // from step 2
       'port' => '3306',
       'name' => 'if0_12345678_codeface',
       'user' => 'if0_12345678',
       'pass' => 'your-password',
       'charset' => 'utf8mb4',
   ],
   ```
5. **Open** `https://yoursite.free.nf/` — it redirects to `frontend/`, creates all 13
   tables and seeds the demo data automatically on that first hit (takes a few seconds).
6. Log in as `alice` / `password123` (or register your own) and run the
   [post-deploy checklist](#post-deploy-checklist).

Shared-host notes:

- **Live rooms**: hosts that buffer long requests (LiteSpeed, proxies) can interrupt
  the SSE stream. Codeface auto-detects repeated SSE failures and silently switches to
  2.5 s polling — rooms stay live either way.
- **Free-tier limits** (hits/day, CPU) apply; fine for demos and portfolio traffic.
- Want a custom domain? Any free subdomain works; InfinityFree also supports pointing
  your own domain at their nameservers.

---

## C. Cloud VPS (best fidelity) — via GitHub Student Developer Pack

education.github.com/pack → free credits for **DigitalOcean, Azure**, etc.

```bash
# on an Ubuntu VM:
sudo apt update && sudo apt install -y apache2 php libapache2-mod-php php-mysql mariadb-server
sudo mysql -e "CREATE DATABASE codeface CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
               CREATE USER 'codeface'@'localhost' IDENTIFIED BY 'strong-pass';
               GRANT ALL ON codeface.* TO 'codeface'@'localhost'; FLUSH PRIVILEGES;"
sudo unzip codeface-deploy.zip -d /var/www/html/          # or git clone
sudo chown -R www-data:www-data /var/www/html/codeface/database/data
sudo a2enmod rewrite headers && sudo systemctl restart apache2
# set creds in backend/config/config.php (or export CODEFACE_DB_* in Apache envvars)
```

On a real VPS everything is first-class: SSE streams, uploads, both DB drivers.
Put Nginx/Caddy or Certbot in front for HTTPS.

---

## D. Docker (Render / Railway / any Docker host)

A `Dockerfile` ships at the repo root (PHP 8.2 + Apache + pdo_mysql). Defaults to
zero-config SQLite (ephemeral — data resets on redeploy), so pass MySQL env vars for a
persistent DB:

```bash
docker build -t codeface .
docker run -p 8080:80 codeface                                    # sqlite demo
docker run -p 8080:80 -e CODEFACE_DB_DRIVER=mysql \
  -e CODEFACE_DB_HOST=... -e CODEFACE_DB_USER=... \
  -e CODEFACE_DB_PASS=... -e CODEFACE_DB_NAME=codeface codeface   # external MySQL
```

On Render: *New → Web Service → from your Git repo → Docker runtime*. Add a free
external MySQL (or Railway's MySQL plugin) and set the `CODEFACE_DB_*` env vars.
`backend/config/config.php` already reads every one of them — no code edits needed.

---

## Post-deploy checklist

1. Home page loads and redirects to `frontend/index.php` automatically.
2. Register a fresh account (proves DB writes).
3. **Two Sum** in JavaScript → Run → Submit → leaderboard points go up.
4. Open `frontend/room.php?code=DEMO42` in **two browsers** (alice + bob) → type in one,
   watch it appear in the other (proves SSE/polling).
5. `frontend/profile.php` → upload a photo (proves file upload + avatar passthrough).
6. Log in as `dev_mike` → Labs/Refactor show the 🔒 practice-gate wall (proves gates).
7. Try downloading `https://yourhost/database/data/codeface.sqlite` → must be **403**
   (proves `.htaccess` protection survived the upload).

## Troubleshooting

| Symptom | Fix |
|---|---|
| 500 on first hit | PHP < 8.0, or PDO driver missing — enable `pdo_mysql`/`pdo_sqlite` |
| DB connection error | wrong host — shared hosts are **not** `localhost`; re-check panel values |
| Styles/scripts missing | hard-refresh (Ctrl+F5); confirm `frontend/assets/` uploaded fully |
| Avatar upload fails | `database/data/avatars/` not writable — chmod 775/777 |
| Rooms lag on shared host | expected — the app is already polling; it's automatic |
| `403` from Apache everywhere | `.htaccess` `Options -Indexes` clashes with host config; comment line 1 of `/.htaccess` |
