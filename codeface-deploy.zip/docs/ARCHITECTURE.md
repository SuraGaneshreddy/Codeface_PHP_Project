# Project Name & Architecture Selection — Codeface

> ESE classroom submission · covers (1) project-name selection and (2) architecture
> selection with justification, alternatives considered, and implementation status.

---

## 1. Project name selection

**Selected name: Codeface** — *"A gym for coders."*

**Why this name**

- **Self-explanatory**: *code* + *face* (interface) — a place where you face code every
  day. One word, easy to say and remember in a demo, and every screen (problems, labs,
  refactors, rooms) is literally a different *face* of coding practice.
- **Matches the identity**: the brand mark in the header is `{ }` — instantly readable as
  a coding platform without needing a logo.
- **Available & neutral**: short, pronounceable, no trademark conflicts with the
  well-known products it's inspired by (LeetCode/HackerRank-style platforms), so it can be
  put on a public URL (e.g. `codeface.free.nf`) without confusion.

**Alternatives considered**: *CodeGym* (already a real product), *DevPair* (describes only
the rooms feature, not practice/learn), *SyntaxArena* (longer, weaker meaning).
Codeface won because it is short, memorable, feature-agnostic and demo-friendly.

---

## 2. Problem the architecture must solve

Students need one place to **practice problems in 12 languages, follow structured learn
tracks, pair-program live, and do job-realistic labs/refactoring** — while the project
constraints are a **vanilla HTML/CSS/JS frontend, a PHP + SQL backend, no frameworks, no
Composer, and no server-side code execution**, and it must demo offline on XAMPP.

## 3. Selected architecture: 3-tier client–server (with judging pushed to Tier 1)

![Architecture diagram](architecture.svg)

| Tier | Layer | Technology | Responsibility |
|---|---|---|---|
| **1 — Presentation** | `frontend/` | vanilla HTML/CSS/JS, Monaco (CDN), Web Workers, Pyodide WASM | pages, editor, **in-browser sandboxed judging** (JS/TS/Python), SSE room client, offline drafts |
| **2 — Application** | `backend/` | PHP 8 + PDO, procedural core in `lib/`, JSON API in `api/`, SSE in `api/rooms/stream.php` | auth & sessions (incl. **forgot-password email OTP** via built-in SMTP client), CSRF, gates (10-solve wall, Learn level locks), AI content engine (`aibank.php`), collab state, scoring |
| **3 — Data** | `database/` | MySQL/MariaDB **or** SQLite (same PDO code, driver switched by env var) | 14 tables · 16 FKs · schema v10, auto-create + auto-seed, upload storage for avatars (web-denied dir) |

**Internal pattern inside Tier 2** — *MVC-inspired layered monolith*:
page scripts act as controllers, `partials/` as the view layer, and `lib/` (db.php data
access + banks + helpers) as the model layer. It deliberately avoids a heavy framework —
the no-Composer rule bans Laravel/Ratchet-style packages.

**The two architectural decisions that define Codeface:**

1. **Judging happens in Tier 1 (edge), not Tier 2.** User code runs inside a browser
   Web Worker / WASM sandbox (infinite loops killed by message-timeout), so the server can
   *never* be harmed by untrusted code — which is what makes the platform safe on a cheap
   vanilla-PHP shared host. Trade-off (documented): submission results are client-reported
   → leaderboard points are honor-system, acceptable for a practice platform.
2. **Real-time uses SSE + POST, not WebSockets.** SSE is one-way (server→client) — exactly
   what pad/chat/presence broadcast needs; edits travel up via ordinary POSTs with
   optimistic version numbers (`409` on conflict). If SSE is blocked by a proxy, the client
   auto-switches to 2.5 s polling — availability by design.

## 4. Why this architecture (justification)

| Constraint / requirement | How the chosen architecture satisfies it |
|---|---|
| Vanilla stack, no frameworks/Composer | plain PHP pages + JSON API; nothing to install |
| Must demo offline on XAMPP | SQLite driver → zero-config DB; judging needs no server; SSE works on `php -S` and Apache as-is |
| Untrusted code can never `exec()` on the server | judging lives in Tier 1 Worker/WASM sandbox |
| Free/cheap hosting target | 3-tier PHP+MySQL deploys to any ₹0 shared host (InfinityFree etc.) unchanged |
| Real-time collaboration | SSE channel + POST writes; graceful polling fallback |
| Two DB engines (demo = SQLite, XAMPP = MySQL) | PDO abstraction behind `db()`; one codebase, both verified (75/75 integration assertions on each) |
| Testability | tier boundaries make curl-level integration tests and a Node content harness possible (`tools/`) |
| Future growth | `pdef()`-style data-driven banks; AI generator module isolated in `aibank.php` |

## 5. Alternatives considered and rejected

| Alternative | Why it looks attractive | Why rejected here |
|---|---|---|
| **MERN / MEAN SPA** | industry default, rich ecosystem | violates the vanilla HTML/CSS/JS + PHP + SQL stack rule; needs Node server hosting |
| **Laravel MVC** | strict MVC, batteries included | Composer packages banned; won't run on the required no-dependency setup |
| **Microservices** | scalability story | massive overkill for a student platform; deployment (free hosts) and debugging become infeasible |
| **Serverless / static + Firebase** | zero ops | breaks SSE, breaks PHP+SQL requirement, adds a paid BaaS dependency and internet-only demos |
| **WebSocket (Ratchet/ReactPHP)** | "true" real-time | Composer dependency (banned); SSE already covers the one-way broadcast need |
| **Server-side judging (exec/compilers)** | verified results | unsafe without OS sandboxing; shared hosts disable `exec()`; kept as roadmap item behind proper isolation |

## 6. Implementation status (architecture → working code)

| Architectural component | Status |
|---|---|
| Tier 1 pages + assets (19 pages, 13 JS modules) | ✅ implemented |
| In-browser judge (Worker: judge/snippet/project modes; Pyodide worker) | ✅ implemented + harness-verified |
| Tier 2 JSON API (16 endpoints) + auth/CSRF gates | ✅ implemented |
| SSE live rooms + polling fallback + matchmaking + 6-letter room codes | ✅ implemented |
| Practice gate (10 solves) & Learn level sequencing | ✅ enforced on pages **and** APIs |
| AI content engine (`aibank.php`) — per-user deterministic problem/lab/repo sets | ✅ implemented, 1084/1084 content assertions |
| Tier 3 dual-driver persistence (MySQL + SQLite), auto-seed | ✅ 75/75 integration pass on both drivers |
| Deployment paths (XAMPP, shared host, VPS, Docker) | ✅ documented in `docs/DEPLOYMENT.md` |
| **Roadmap**: isolated server-side judge, CRDT sync, optional WS daemon | ⏳ next phases |

## 7. Data flow (typical request)

1. Browser `GET /frontend/problem.php?slug=two-sum` → PHP page (controller) → `lib/` loads
   the problem row via PDO → `partials/` render escaped HTML + CSRF token.
2. Student presses `Ctrl+Enter` → `runner.js` spawns a Worker; tests evaluated in-browser;
   result JSON `POST /backend/api/submissions.php` (CSRF header) → validated → row written;
   rating updated atomically.
3. In a room: `EventSource backend/api/rooms/stream.php` pushes snapshot+diffs every 600 ms;
   partner edits `POST push.php` with `base_version`; conflict → `409` + adopt server copy.

## 8. Quality attributes delivered by this architecture

- **Security**: bcrypt passwords, session regeneration, CSRF everywhere, prepared
  statements only, output escaping, no server-side eval, `.htaccess`-denied data dirs.
- **Portability**: same tree runs on `php -S`, XAMPP Apache, shared hosting, Docker.
- **Reliability/availability**: SSE→polling fallback; idempotent versioned re-seeding.
- **Testability**: driver-agnostic integration suite (`ITEST_*` env) + content provers.
- **Honesty**: every architectural trade-off is documented in README *Assumptions &
  flagged deviations* (1–7) rather than hidden.

---

**One-line submission summary:** *Codeface — a 3-tier client–server web application
(vanilla HTML/CSS/JS presentation, PHP 8 + PDO application layer with SSE real-time,
MySQL/SQLite data layer) whose judging sandbox is deliberately pushed into the browser so
untrusted code can run safely on any vanilla-PHP host.*
